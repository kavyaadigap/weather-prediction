#
# Copyright (c) 2017-18 Jonathan Weyn <jweyn@uw.edu>
#
# See the file LICENSE for your rights.
#

"""
DLWP, or Deep Learning Weather Prediction, is a module for predicting weather using deep learning.
"""

__version__ = '0.7.0'
